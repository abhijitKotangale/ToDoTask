//
//  ToDoTableViewCell.m
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/3/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import "ToDoTableViewCell.h"

@implementation ToDoTableViewCell
@synthesize bgMainView,contentView;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    bgMainView.layer.shadowRadius  = 1.5f;
    bgMainView.layer.shadowColor   = [UIColor colorWithRed:176.f/255.f green:199.f/255.f blue:226.f/255.f alpha:1.f].CGColor;
    bgMainView.layer.shadowOffset  = CGSizeMake(0.0f, 0.0f);
    bgMainView.layer.shadowOpacity = 0.9f;
    bgMainView.layer.masksToBounds = NO;
    bgMainView.layer.cornerRadius = 10;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
