//
//  ViewController.h
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/2/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (strong, nonatomic) NSMutableArray *arrayMainData;
@property (weak, nonatomic) IBOutlet UIView *sortView;
@property (weak, nonatomic) IBOutlet UIButton *btnSortOutlet;

//Dashboard outlet
@property (weak, nonatomic) IBOutlet UIView *dashboardView;

- (IBAction)btnSortAction:(UIButton *)sender;
@end

