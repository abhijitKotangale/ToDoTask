//
//  ViewController.m
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/2/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import "ViewController.h"
#import "ToDoTableViewCell.h"
#import "database.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tblView,arrayMainData,sortView,btnSortOutlet,dashboardView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self animationView];
    
    //array = @[@"ASSETS",@"TROUBLESHOOT",@"ASSETS",@"TROUBLESHOOT"];
    NSString *strShowData = [[NSString alloc]initWithFormat:@"select * from todo"];
    database *db = [[database alloc]init];
    arrayMainData = [[NSMutableArray alloc]init];
    arrayMainData = [db getAllUser:strShowData];
    
    sortView.hidden = YES;
    tblView.delegate = self;
    tblView.dataSource = self;
    [tblView reloadData];
}

-(void)animationView{
    
    dashboardView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    [UIView animateWithDuration:0.5 delay:1.0 usingSpringWithDamping:0.7f initialSpringVelocity:1.f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.dashboardView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.0, 1.0);
    } completion:^(BOOL finished) {
        self.dashboardView.transform = CGAffineTransformIdentity;
    }];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return arrayMainData.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ToDoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        
        cell = [[ToDoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.lblCategory.text = [NSString stringWithFormat:@"%@", [[arrayMainData objectAtIndex:indexPath.row] objectForKey:@"category"]];
    
    NSLog(@"---->  %@", cell.lblCategory.text);
    
    return cell;
}

- (IBAction)btnSortAction:(UIButton *)sender {
    
    btnSortOutlet.selected  = ! btnSortOutlet.selected;
    
    if (sender.selected)
    {
        [UIView transitionWithView:sortView duration:0.4 options:UIViewAnimationOptionTransitionFlipFromTop animations:^{
            self->sortView.hidden = NO;
        }completion:NULL];
        
    }
    else
    {
        [UIView transitionWithView:sortView duration:0.1 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{
            self->sortView.hidden = YES;
        }completion:NULL];
    }
}

@end
