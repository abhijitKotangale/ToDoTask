//
//  ToDoTableViewCell.h
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/3/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ToDoTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *bgMainView;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UILabel *lblCategory;

@end

NS_ASSUME_NONNULL_END
