//
//  AppDelegate.h
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/2/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSString *strPath;

-(void)getDBPath;

@end

