//
//  main.m
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/2/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
