//
//  ViewController.m
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/2/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import "ViewController.h"
#import "ToDoTableViewCell.h"
#import "database.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tblView,arrayMainData;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //array = @[@"ASSETS",@"TROUBLESHOOT",@"ASSETS",@"TROUBLESHOOT"];
    
    NSString *strShowData = [[NSString alloc]initWithFormat:@"select * from todo"];
    database *db = [[database alloc]init];
    arrayMainData = [[NSMutableArray alloc]init];
    arrayMainData = [db getAllUser:strShowData];
    
    tblView.delegate = self;
    tblView.dataSource = self;
    [tblView reloadData];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return arrayMainData.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ToDoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        
        cell = [[ToDoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.lblCategory.text = [NSString stringWithFormat:@"%@", [[arrayMainData objectAtIndex:indexPath.row] objectForKey:@"category"]];
    
    NSLog(@"---->  %@", cell.lblCategory.text);
    
    return cell;
}

@end
