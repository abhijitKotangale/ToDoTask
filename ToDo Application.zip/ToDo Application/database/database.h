//
//  database.h
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/3/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface database : NSObject
{
    AppDelegate *appDelegate;
    sqlite3 *db;
}

@property (strong,nonatomic)NSMutableArray *mutArray;
@property (strong,nonatomic)NSString *strMain;

-(NSMutableArray *)getAllUser:(NSString *)query;

@end

NS_ASSUME_NONNULL_END
