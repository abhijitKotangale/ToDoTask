//
//  database.m
//  ToDo Application
//
//  Created by Abhijit Kotangale on 1/3/19.
//  Copyright © 2019 Augment Deck Technologies LLP. All rights reserved.
//

#import "database.h"

@implementation database
@synthesize strMain,mutArray;

-(id)init{
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    strMain = appDelegate.strPath;
    
    return self;
}

-(NSMutableArray *)getAllUser:(NSString *)query{
    
    mutArray = [[NSMutableArray alloc]init];
    
    if (sqlite3_open([strMain UTF8String], &db) == SQLITE_OK) {
        
        sqlite3_stmt *connection;
        if (sqlite3_prepare_v2(db, [query UTF8String], -1, &connection, nil)==SQLITE_OK) {
            
            while (sqlite3_step(connection)==SQLITE_ROW) {
                
                NSMutableDictionary *mutDic = [[NSMutableDictionary alloc]init];
                NSString *strId = [[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(connection, 0)];
                NSString *strCategory = [[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(connection, 1)];
                NSString *strdis = [[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(connection, 2)];
                NSString *strStatus = [[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(connection, 3)];
                NSString *strName = [[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(connection, 4)];
                
                [mutDic setObject:strId forKey:@"todo_id"];
                [mutDic setObject:strCategory forKey:@"category"];
                [mutDic setObject:strdis forKey:@"dis"];
                [mutDic setObject:strStatus forKey:@"status"];
                [mutDic setObject:strName forKey:@"name"];
                
                NSString *log = [NSString stringWithFormat:@"%@-%@-%@-%@",strCategory,strdis,strStatus,strName];
                [mutArray addObject:mutDic];
            }
        }
        
        sqlite3_finalize(connection);
    }
    
    sqlite3_close(db);
    return mutArray;
}

@end
